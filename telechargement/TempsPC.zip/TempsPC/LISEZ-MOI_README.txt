Temps PC 1.3 - temps passe sur l'ordinateur / time spent on the computer

=== FRANCAIS ===

Installation : place le dossier TempsPC ou il restera (par ex. Documents),
puis double-clique sur TempsPC.exe.
Si Windows affiche "Windows a protege votre ordinateur" :
"Informations complementaires", puis "Executer quand meme".

Mise a jour : dans Temps PC, clique sur "Quitter", remplace l'ancien
TempsPC.exe par celui-ci AU MEME ENDROIT, puis relance-le.
Tes donnees (%APPDATA%\TempsPC) sont conservees, avec une copie de
securite automatique dans %APPDATA%\TempsPC\sauvegardes.

Langues : anglais, chinois, hindi, espagnol, arabe, francais
(celle de Windows, ou au choix dans Reglages).

=== ENGLISH ===

Install: put the TempsPC folder where it will stay (e.g. Documents),
then double-click TempsPC.exe.
If Windows shows "Windows protected your PC":
"More info", then "Run anyway".

Update: in Temps PC, click "Quit", replace the old TempsPC.exe with
this one IN THE SAME PLACE, then start it again.
Your data (%APPDATA%\TempsPC) is kept, with an automatic backup
in %APPDATA%\TempsPC\sauvegardes.

Languages: English, Chinese, Hindi, Spanish, Arabic, French
(same as Windows, or choose it in Settings).

