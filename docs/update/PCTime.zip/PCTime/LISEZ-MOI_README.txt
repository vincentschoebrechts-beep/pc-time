PC Time 1.5 - screen time for your Windows PC / le temps d'ecran de ton PC
(formerly / anciennement "Temps PC")

=== ENGLISH ===

Install: put the PCTime folder where it will stay (e.g. Documents),
then double-click PCTime.exe.
If Windows shows "Windows protected your PC":
"More info", then "Run anyway".

New versions: greenserver.be/update
(or "Check for updates" in Settings).

Update (also from Temps PC): in the app, click "Quit", put PCTime.exe
in the SAME FOLDER as the old exe and start it. Automatic startup switches
to PCTime.exe by itself; you can then delete the old TempsPC.exe.
Your data (%APPDATA%\TempsPC) is kept, with an automatic backup
in %APPDATA%\TempsPC\sauvegardes.

Languages: English, Chinese, Hindi, Spanish, Arabic, French
(same as Windows, or choose it in Settings).

PC Time is free. Once a month, a small line suggests a coffee
to support it, with an "Update" button; "Already done" or the little
cross hides it for a month.

=== FRANCAIS ===

Installation : place le dossier PCTime la ou il restera (par ex. Documents),
puis double-clique sur PCTime.exe.
Si Windows affiche "Windows a protege votre ordinateur" :
"Informations complementaires", puis "Executer quand meme".

Nouvelles versions : greenserver.be/update
(ou "Rechercher une mise a jour" dans Reglages).

Mise a jour (aussi depuis Temps PC) : dans l'appli, clique sur "Quitter",
place PCTime.exe dans le MEME DOSSIER que l'ancien exe et lance-le.
Le demarrage automatique passe tout seul sur PCTime.exe ; tu peux ensuite
supprimer l'ancien TempsPC.exe.
Tes donnees (%APPDATA%\TempsPC) sont conservees, avec une copie de
securite automatique dans %APPDATA%\TempsPC\sauvegardes.

Langues : anglais, chinois, hindi, espagnol, arabe, francais
(celle de Windows, ou au choix dans Reglages).

PC Time est gratuit. Une fois par mois, une petite ligne propose un cafe
pour le soutenir, avec un bouton "Mise a jour" ; "C'est deja fait" ou la
petite croix la cache pour un mois.
